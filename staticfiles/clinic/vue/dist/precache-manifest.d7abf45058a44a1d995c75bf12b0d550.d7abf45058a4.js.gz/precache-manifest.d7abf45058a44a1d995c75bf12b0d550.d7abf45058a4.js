self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f4658c64e66056d24d9407f2033461ea",
    "url": "/static/clinic/vue/dist/_index.html"
  },
  {
    "revision": "a459b46956a293030db5",
    "url": "/static/clinic/vue/dist/css/app.css"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/static/clinic/vue/dist/img/logo.png"
  },
  {
    "revision": "f5de91b16b88b4baeeaae0cd19279ab8",
    "url": "/static/clinic/vue/dist/index.html"
  },
  {
    "revision": "018310081ef48251c370",
    "url": "/static/clinic/vue/dist/js/about.js"
  },
  {
    "revision": "a459b46956a293030db5",
    "url": "/static/clinic/vue/dist/js/app.js"
  },
  {
    "revision": "067cdc69b975358cc2a2",
    "url": "/static/clinic/vue/dist/js/chunk-vendors.js"
  },
  {
    "revision": "67b2b90f166cf98ca181277c50a6800e",
    "url": "/static/clinic/vue/dist/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/static/clinic/vue/dist/robots.txt"
  }
]);