self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9f1cb670146713a6620b",
    "url": "/css/app.css"
  },
  {
    "revision": "37bce3df5be01c016218e2fcfc4a8bbc",
    "url": "/index.html"
  },
  {
    "revision": "9f1cb670146713a6620b",
    "url": "/js/app.js"
  },
  {
    "revision": "fcf34ddbb4fa1d858b06",
    "url": "/js/chunk-vendors.js"
  },
  {
    "revision": "27b1ab3fec5c4c6e5b08437fcc4becdc",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);